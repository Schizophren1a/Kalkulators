﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CalorieCalculator;


namespace CalorieCalculator
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            double weight = Convert.ToDouble(textBoxWeight.Text);
            double height = Convert.ToDouble(textBoxHeight.Text);
            int age = Convert.ToInt32(textBoxAge.Text);
            string gender = comboBoxGender.SelectedItem.ToString();

            double bmr = 0;

            double activityLevel = Convert.ToDouble(textBoxActivityLevel.Text);
            double targetWeight = Convert.ToDouble(textBoxTargetWeight.Text);

            if (gender == "Male")
            {
                bmr = 66 + (13.7 * weight) + (5 * height) - (6.8 * age);
            }
            else if (gender == "Female")
            {
                bmr = 655 + (9.6 * weight) + (1.8 * height) - (4.7 * age);
            }

            double weightLossRate = (weight - targetWeight) / weight;

            double maintenanceCalories = bmr * activityLevel;
            double weightLossCalories = maintenanceCalories * (1 - weightLossRate);

            labelResult.Text = "Maksimālais kaloriju daudzums dienā tievēšanai.: " + weightLossCalories.ToString();
        }
    }
}

